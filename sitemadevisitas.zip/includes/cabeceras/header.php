<!doctype html>
 <html lang="en">
 
 <head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="description" content="">
   <meta name="author" content="Erickson Espejo">
   <meta name="generator" content="Hugo 0.72.0">
   <title>Sistema de Visitas de la municipalidad distrital de Aquia</title>
   <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
   <link rel="stylesheet" href="assets/DataTables/datatables.css">
   <!-- <link rel="stylesheet" href="assets/css/style.css"> -->
   <script src="assets/DataTables/jQuery-3.6.0/jquery-3.6.0.min.js"></script>
   <script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>
   <script src="assets/DataTables/datatables.js"></script>
   <script src="assets/plugins/js/dataTables.js"></script>
 </head>
 
 <body>
 