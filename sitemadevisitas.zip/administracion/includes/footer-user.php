<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyright &copy; <a href="http://bussineswebsite.com" target="_blank" rel="noopener noreferrer"></a></div>
            <div>
                <a href="#">Politicas de privacidad</a> &middot;
                <a href="#">Terminos &amp; Condiciones</a>
            </div>
        </div>
    </div>
</footer>
</div>
</div>
</body>

</html>