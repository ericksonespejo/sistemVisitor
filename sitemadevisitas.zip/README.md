# sistemVisitor
Sistema de registro de visitas
## Creando el sistema de visitas para municipalidades
### cada que pueda ire actualizando el repo
